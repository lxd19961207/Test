package com.education.dao.impl;

import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import com.education.contant.Contant;
import com.education.dao.I_LoginDao;
import com.education.entity.Student;
import com.education.entity.User;
import com.education.util.JdbcUtils;
//登录功能实现类
public class I_loginDaoImpl  implements I_LoginDao {
	JdbcTemplate   jdbc=new JdbcTemplate(JdbcUtils.getDataSource());
	@Override
	public User login(String username,String password,String type) {
//返回tb_login表所有的结果集
	String sql="select * from tb_login where username = "+username+" and password= "+password+" and type=?";
    return  jdbc.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class),type);
	}
	
}
