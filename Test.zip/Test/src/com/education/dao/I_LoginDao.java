package com.education.dao;

import java.util.List;

import com.education.entity.User;
//登录功能
public interface I_LoginDao {
	User login(String username,String password,String type);
}
