package com.education.entity;
//持久化学生对象
public class Student {
  String name;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
}
