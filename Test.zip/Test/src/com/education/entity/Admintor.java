package com.education.entity;
//持久化管理员对象
public class Admintor  {
     
}
