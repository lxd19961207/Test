package com.education.entity;
//持久化教师对象
public class Teacher {

}
