package com.education.controller;

import javax.print.attribute.standard.RequestingUserName;
import javax.servlet.annotation.WebServlet;

import com.education.entity.User;
import com.education.service.I_loginSerivice;
import com.education.service.impl.I_loginSeriviceImpl;

import java.io.IOException;


public class LoginServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
    	    //制定编码集
    	  request.setCharacterEncoding("utf-8");
            //接受username,password和type参数
    	  String  username=request.getParameter("username");
    	  String  password=request.getParameter("password");
    	  String  type=request.getParameter("type");
    	    //判断参数是否为空
    	     //非空
    	     if(username!=null&password!=null) {
    	       //封装User对象
    	    	 I_loginSerivice ilogin=new  I_loginSeriviceImpl();
    	    	 User user=ilogin.login(username,password,type);
    	    	//判断用户是否存在
	    	        // 存在
	    	       if(user!=null) {
	    	             //判断用户类型
	    	    	     if("学生".equals(user.getType())) {
	    	    	    	 //跳到学生主页
	    	    	    	  request.getRequestDispatcher("").forward(request, response);
	    	    	     }
	    	    	     if("老师".equals(user.getType())) {
	    	    	    	 //跳到老师主页
	    	    	    	 request.getRequestDispatcher("").forward(request, response);
	    	    	     }
	    	    	     if("校长".equals(user.getType())) {
	    	    	    	 //跳到校长主页
	    	    	    	 request.getRequestDispatcher("").forward(request, response);
	    	    	     }
	    	    	     else {
	    	    	    	 System.out.println("我是");
	    	    	     }
	    	       }
	    	       //不存在
	    	       else {
	    	    	 //跳到失败页
	    	    	   response.sendRedirect(request.getContextPath()+"/failed.html");
	    	       }
    	     }
    	     //空
    	     else {
    	    	 //跳到失败页
    	    	   response.sendRedirect(request.getContextPath()+"/failed.html");
    	     }
    	         
    }
}
