package com.education.service.impl;

import com.education.dao.impl.I_loginDaoImpl;
import com.education.entity.User;
import com.education.service.I_loginSerivice;

public class I_loginSeriviceImpl implements  I_loginSerivice{
	@Override
	public User login(String username, String password, String type) {
		 return new I_loginDaoImpl().login(username, password, type);
	}}
