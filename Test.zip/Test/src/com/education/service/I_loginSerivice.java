package com.education.service;

import com.education.entity.User;

public interface I_loginSerivice {
     User login(String username,String password,String type);
}
